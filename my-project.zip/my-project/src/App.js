import React, { Component }  from 'react';
import './App.css';
import Header from './Mycomponents/Header';
import Main from './Mycomponents/Main';
import Cards from './Mycomponents/Cards';

function App() {
  return (
<>
<Header/>


<Main/>
<br></br>
<br></br>
<br></br>
<br></br>
<Cards/>


     
   
</>

  );
}

export default App;
