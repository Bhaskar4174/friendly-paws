import React from 'react'

export default function Donate() {
  return (
   
<form>
        <label>
            Donate For The Needy Ones
        </label><br></br>
        <label>Your Name</label><br></br>
        <input
        type = "text"
        required/><br></br>

<label>Your Phone Number</label><br></br>
        <input
        type = "text"
        required/><br></br>
        <label>Choose What You Want to Contribute</label>
        <select>
            <option value="Money">Money</option> 
            <option value="Goodies">Goodies</option> 
        </select>
        if(Money){
            <><input
                  type="text"
                  required /><br></br></>
        }



</form>
  )
}
