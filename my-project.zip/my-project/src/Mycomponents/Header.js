import React from 'react'

import './Header.css';
import logo from '../images/logo.png'
import pic from '../images/anim.jpg'
import Donate from './Donate';
import Typewriter from 'typewriter-effect'


export default function Header() {
  return (
    <><><nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="container-fluid">
        <img src={logo}></img>
        <a className="navbar-brand" href="#">   Friendly Paws </a>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div className="navbar-nav">
            <a className="nav-link active" aria-current="page" href="#">Home</a>
            <a className="nav-link" href="#">Features</a>
            <a className="nav-link" href="#">Pricing</a>
          </div>
        </div>
      </div>
    </nav>

      <div className="card mb-3">
        <div className="row g-0">
          <div className="col-md-4">
            <img src={pic} className="img-fluid rounded-start" alt="..." />
          </div>
          <div className="col-md-8">
            <div className="card-body-1">
              <div className="card-title">
            <Typewriter
            options={{
              strings:['Friendly Paws','About Us'],
              autoStart:true,
              loop:true,
              pauseFor:2000
            }}
            />
            </div>
              <p className="card-text-1">Our organisation 'Friendly Paws' is a non profitable organisation which is trying its best to serve for animal welfare. A bunch of volunteers and some professional vets gathered just to help these helpless creatures.<br></br> 'A Friend in Need is a Friend Indeed' is the motto of our organisation .This organisation was started by a group of friends who were there to help these animals during the pandemic. <br></br>  
              Our organisation provides Food, Shelter ,Medical assistance and lots of love to these beautiful creatures of God.<br></br>
              You can also help these animals by volunteerly joining our organisation or by contributing. Let's unitedly makle this world a better place to live for these lovely creatures.
              </p>

            </div>
          </div>
        </div>
      </div></>
      
      </>
      
  )
}
