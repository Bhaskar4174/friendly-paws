import React from 'react'
import './Cards.css'

import doct from '../images/doctor2.jpg'
import feed from '../images/feed.jpg'
import shelter from '../images/shelter2.jpg'
import friends from '../images/friends.jpg'
import Typewriter from 'typewriter-effect'
export default function Cards() {
  return (
    <>
    <div className="row row-cols-1 row-cols-md-3 g-4">
      <div className="col my-3 mx-2">
        <div className="card h-100">
          <img src={shelter} height="250px" width="100%" alt="..." className="card-img"/>
          <div className="card-body">
            <h3 className="card-title-c">Shelter To The Homeless</h3>
        
            <p className="card-text">You can help the needy animals by adopting them or by contacting our team, we will try our best to find best shelter fot those animals.</p>
          </div>
          <div className="card-footer">


            <small className="text-muted"><a className="button-1" href="#" role="button">Adopt</a>

              <button className="button-2" type="submit">Report Us</button>
            </small>
          </div>


        </div>
      </div>
      <div className="col my-3 mx-2">
        <div className="card h-100">
          <img src={doct} height="200px" width="100%" alt="..." className="card-img-2"  />
          <div className="card-body">
            <h1 className="card-title-c">Medical Assistance</h1>
            <p className="card-text">
            If you see any animal on streets who is looking ill or injured, you may contact our team so we unitedly can save them. Or if you are an animal medical expert , you can voluteerly join our medical team.</p>

          </div>
          <div className="card-footer">
          <small className="text-muted"><a className="button-1" href="#" role="button">Join Us</a>

<button className="button-2" type="submit">Report us</button>
</small>
          </div>
        </div>
      </div>
      <div className="col my-3 mx-2">
        <div className="card h-100">
          <img src={feed} height="200px" width="100%" alt="..." className="feed-3" />
          <div className="card-body">
            <h1 className="card-title-c">Feed the Good</h1>
            <p className="card-text">You may help our team by telling abou the needy animals or you can help with buying some food for the animals at streets or at our shelter.</p>
          </div>
          <div className="card-footer">
          <small className="text-muted"><a className="button-1" href="#" role="button">Donate</a>

<button className="button-2" type="submit">Report Us</button>
</small>
          </div>
        </div>
      </div>
    </div>
    
    <br></br>
    <br></br>
    <br></br>
    <div className="final" >
        <img src={friends} className="friends" />
        <div className="final-body">
          <div className="card-title">
            <Typewriter
            options={{
              strings:['WE ARE BEST FRIENDS OF ANIMALS','We Should Help Our Best Friends'],
              autoStart:true,
              loop:true,
              pauseFor:2000
            }}
            />
          </div>
          <p className="card-text"></p>
          <p className="card-text"><small className="text-muted">Last updated 3 mins ago</small></p>
        </div>
      </div></>
  )
}
